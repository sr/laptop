# Python Puppet Module for Boxen

Requires the following boxen modules:

* `boxen`
* `homebrew`

## Usage

For now this is lightweight.
We'll want to add virtualenv support someday.

```puppet
include python
```