#Contributing

* Fork it
* Fix it
* Test it
* Pull Request it

