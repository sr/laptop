# XQuartz Puppet Module for Boxen

Requires the following boxen modules:

* `boxen`

## Usage

```puppet
include xquartz
```

## Developing

Write code.

Run `script/cibuild`.
